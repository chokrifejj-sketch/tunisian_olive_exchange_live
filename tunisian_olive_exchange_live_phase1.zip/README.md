# Tunisian Olive Oil Exchange — live-data integration (Phase 1)

This package upgrades the static Cloudflare Pages site with a Pages Function at `GET /api/prices`.

## Included in this phase

- A server-side adapter to the Tunisian National Open Data Portal CKAN datastore.
- The Office National de l'Huile dataset `Prix moyens à la production de l'huile d'olive extra vierge` (resource `ffe9d7e0-e894-4c8c-aa3e-99d6de596007`).
- Mill purchase prices are returned by governorate with source date and published min/max TND/kg values.
- The midpoint is explicitly labelled as a simple midpoint, not a weighted market average.
- Six-hour edge caching reduces load on the source.
- No fabricated fallback values are returned.

## Important scope boundary

This is **not yet a fully automated global exchange**. The Tunisian mill-price adapter is implemented. The official ONH vigilance portal documents mill activity, olive-market prices and export flows, but a supported public machine-readable feed for Tunisian FOB/export price quotations has not yet been verified. The European Commission publishes weekly EU price data and has an API, but its olive-oil API operation/schema must be validated before figures are wired into production. Until those steps are complete, those sections explicitly return an unavailable/pending state rather than invented prices.

## Deploy to Cloudflare Pages

Cloudflare Pages Functions require a Functions-capable deployment. A simple dashboard drag-and-drop static upload does not deploy this `functions/` directory.

Recommended:

1. Put the contents of this folder in a GitHub repository (include `index.html` at the repository root and keep `functions/api/prices.js`).
2. In Cloudflare Dashboard open **Workers & Pages → Create application → Pages → Connect to Git**.
3. Select the repository.
4. Framework preset: **None**. Build command: leave empty. Build output directory: `.` (repository root).
5. Deploy. Cloudflare will publish the page and the `/api/prices` Function together.
6. Test `https://YOUR-SITE.pages.dev/api/prices` and confirm a JSON response.

If the current site is a dashboard drag-and-drop project, its dashboard drag-and-drop workflow cannot deploy Functions. You can deploy this package to that existing Pages project with Wrangler CLI, or create a separate Git-integrated Pages project. A Direct Upload project cannot later be converted into a Git-integrated project.

## Next production steps

1. Validate the European Commission olive-oil API operation using its OpenAPI specification and map the country/grade/time-series fields.
2. Integrate the official ONH vigilance portal or another authorized government feed for Tunisian export quantities/values. If only monthly export value and volume are available, label the result **average export unit value** (value ÷ volume), not an FOB spot quote.
3. Add a separate scheduled Cloudflare Worker + D1 database for durable historical snapshots and automatic weekly refresh. Pages Functions are request-driven; edge cache expiry alone is not a guaranteed scheduled refresh.
4. Add exchange-rate feed from the Central Bank of Tunisia or ECB with its own timestamp and source.
5. Add monitoring for stale/missing data and source schema changes.

## Data source

- ONH open-data dataset: https://catalog.data.gov.tn/fr/dataset/66444aa2-dead-453a-86ad-877f3fb01d67
- Resource: https://catalog.data.gov.tn/fr/dataset/66444aa2-dead-453a-86ad-877f3fb01d67/resource/ffe9d7e0-e894-4c8c-aa3e-99d6de596007
- ONH vigilance portal: https://www.onh.com.tn/?p=1458
- European Commission olive-oil data: https://agridata.ec.europa.eu/extensions/dataportal/olive-oil.html
- European Commission API documentation: https://agridata.ec.europa.eu/extensions/API_Documentation/GeneralInfo.html
