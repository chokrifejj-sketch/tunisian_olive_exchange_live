/**
 * Cloudflare Pages Function: GET /api/prices
 * Live source adapter for Tunisia mill-gate extra-virgin olive-oil prices.
 * Source: Tunisia National Open Data Portal / Office National de l'Huile.
 * Resource: ffe9d7e0-e894-4c8c-aa3e-99d6de596007
 *
 * Important: this resource is the official purchase-price range paid by mills,
 * not an export/FOB quotation. Export prices are intentionally returned as
 * unavailable until a machine-readable official source is verified.
 */
const RESOURCE_ID = "ffe9d7e0-e894-4c8c-aa3e-99d6de596007";
const DATASET_URL = "https://catalog.data.gov.tn/fr/dataset/66444aa2-dead-453a-86ad-877f3fb01d67/resource/ffe9d7e0-e894-4c8c-aa3e-99d6de596007";
const API_URL = "https://catalog.data.gov.tn/api/3/action/datastore_search";

function numberOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(String(value).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function dateValue(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toISOString().slice(0, 10);
}

export async function onRequestGet({ request }) {
  const url = new URL(request.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || 300), 1), 1000);
  const upstream = new URL(API_URL);
  upstream.searchParams.set("resource_id", RESOURCE_ID);
  upstream.searchParams.set("limit", String(limit));
  upstream.searchParams.set("sort", "Date desc");

  try {
    const response = await fetch(upstream.toString(), {
      headers: { "Accept": "application/json", "User-Agent": "TunisianOliveOilExchange/1.0" },
      cf: { cacheTtl: 21600, cacheEverything: true }
    });
    if (!response.ok) throw new Error(`Open-data portal returned HTTP ${response.status}`);
    const payload = await response.json();
    if (!payload?.success || !Array.isArray(payload?.result?.records)) {
      throw new Error("Unexpected response from the Tunisian open-data portal");
    }

    const rows = payload.result.records.map((r) => {
      const min = numberOrNull(r.Prix_min ?? r.prix_min ?? r["Prix_min"]);
      const max = numberOrNull(r.Prix_max ?? r.prix_max ?? r["Prix_max"]);
      return {
        governorate: r.Gouvernorat ?? r.gouvernorat ?? null,
        date: dateValue(r.Date ?? r.date),
        minTndKg: min,
        maxTndKg: max,
        averageTndKg: min !== null && max !== null ? Number(((min + max) / 2).toFixed(3)) : null,
        category: "extra_virgin",
        market: "mill_purchase",
        currency: "TND",
        unit: "kg"
      };
    }).filter(r => r.minTndKg !== null || r.maxTndKg !== null)
      .sort((a,b) => String(b.date || "").localeCompare(String(a.date || "")));

    const latestDate = rows.reduce((latest, r) => r.date && (!latest || r.date > latest) ? r.date : latest, null);
    const latestRows = latestDate ? rows.filter(r => r.date === latestDate) : [];
    const validMins = latestRows.map(r => r.minTndKg).filter(Number.isFinite);
    const validMaxs = latestRows.map(r => r.maxTndKg).filter(Number.isFinite);

    const body = {
      generatedAt: new Date().toISOString(),
      refreshPolicy: "6h cache; upstream dataset updates according to publisher cadence",
      prices: {
        tunisiaMill: {
          status: latestRows.length ? "live_source" : "no_observations",
          label: "Tunisia · mill purchase price · extra virgin",
          date: latestDate,
          currency: "TND",
          unit: "kg",
          minTndKg: validMins.length ? Math.min(...validMins) : null,
          maxTndKg: validMaxs.length ? Math.max(...validMaxs) : null,
          observations: latestRows,
          source: "Office National de l'Huile — National Open Data Portal",
          sourceUrl: DATASET_URL,
          apiUrl: upstream.toString()
        },
        tunisiaExport: {
          status: "source_not_machine_verified",
          label: "Tunisia · export price",
          currency: "TND",
          unit: "kg",
          value: null,
          note: "No official, machine-readable export-price feed has yet been verified. Export value/quantity statistics must not be presented as a live quote.",
          sourceUrl: "https://www.onh.com.tn/?p=1458"
        },
        euMarkets: {
          status: "integration_pending",
          note: "The European Commission publishes weekly olive-oil price data and documents an API. The olive-oil endpoint/schema still needs to be validated before displaying figures.",
          sourceUrl: "https://agridata.ec.europa.eu/extensions/dataportal/olive-oil.html"
        }
      },
      history: rows,
      methodology: "The mill-gate range is shown as published. The average is a simple midpoint of the published minimum and maximum, not a weighted market average. No missing value is estimated."
    };

    return new Response(JSON.stringify(body), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "public, max-age=300, s-maxage=21600",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      error: "price_feed_unavailable",
      message: error instanceof Error ? error.message : "Unknown upstream error",
      generatedAt: new Date().toISOString(),
      prices: null
    }), {
      status: 502,
      headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" }
    });
  }
}
